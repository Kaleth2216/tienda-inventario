import { Injectable } from '@nestjs/common';
import * as fs from 'fs-extra';
import { join } from 'path';

@Injectable()
export class ProductsService {
    private filePath = join(process.cwd(), 'src', 'data', 'products.json');


  async findAll() {
    const data = await fs.readJson(this.filePath);
    return data;
  }

  async findOneById(id: number) {
    const data = await fs.readJson(this.filePath);
    return data.find((product) => product.id === id);
  }
}
