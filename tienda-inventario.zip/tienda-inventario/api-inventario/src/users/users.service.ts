import { Injectable, InternalServerErrorException } from '@nestjs/common';
import * as fs from 'fs-extra';
import { join } from 'path';

@Injectable()
export class UsersService {
  private filePath = join(process.cwd(), 'src', 'data', 'users.json');

  async findAll() {
    try {
      const data = await fs.readJson(this.filePath);
      return data;
    } catch (error) {
      console.error('Error al leer users.json:', error);
      throw new InternalServerErrorException('Error al leer los usuarios');
    }
  }

  async findOneById(id: number) {
    try {
      const data = await fs.readJson(this.filePath);
      return data.find((user) => user.id === id);
    } catch (error) {
      console.error('Error al buscar el usuario:', error);
      throw new InternalServerErrorException('Error al buscar el usuario');
    }
  }
}
