import { Injectable, InternalServerErrorException } from '@nestjs/common';
import * as fs from 'fs-extra';
import { join } from 'path';

@Injectable()
export class OrdersService {
  private filePath = join(process.cwd(), 'src', 'data', 'orders.json');

  async findAll() {
    try {
      const data = await fs.readJson(this.filePath);
      return data;
    } catch (error) {
      console.error('Error al leer orders.json:', error);
      throw new InternalServerErrorException('Error al leer los pedidos');
    }
  }

  async findOneById(id: number) {
    try {
      const data = await fs.readJson(this.filePath);
      return data.find((order) => order.id === id);
    } catch (error) {
      console.error('Error al buscar el pedido:', error);
      throw new InternalServerErrorException('Error al buscar el pedido');
    }
  }
}
