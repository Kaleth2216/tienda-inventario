import { Injectable, InternalServerErrorException } from '@nestjs/common';
import * as fs from 'fs-extra';
import { join } from 'path';

@Injectable()
export class CategoriesService {
  private filePath = join(process.cwd(), 'src', 'data', 'categories.json');

  async findAll() {
    try {
      const data = await fs.readJson(this.filePath);
      return data;
    } catch (error) {
      console.error('Error al leer categories.json:', error);
      throw new InternalServerErrorException('Error al leer las categorías');
    }
  }

  async findOneById(id: number) {
    try {
      const data = await fs.readJson(this.filePath);
      return data.find((category) => category.id === id);
    } catch (error) {
      console.error('Error al buscar la categoría:', error);
      throw new InternalServerErrorException('Error al buscar la categoría');
    }
  }
}
